"""
    Log tools
    ==========

    Contains multipurpose utilities for interfacing with the logging
    facilities

    .. Copyright:
        Copyright 2018 Wirepas Ltd. All Rights Reserved.
        See file LICENSE.txt for full license details.
"""
import sys
import logging


def setup_log(module, level='debug', log_format="%(asctime)s | [%(levelname)s] %(name)s: %(message)s"):
    """
    Prepares logging.

    Setups Python's logging and by default send up to LEVEL
    logs to stdout.

    Args:
        level - logging level to enable.
    """
    DEBUG_LEVELV_TIMING = 55

    logger = logging.getLogger(module)
    level = '{0}'.format(level.upper())

    try:
        logger.setLevel(eval('logging.{0}'.format(level)))
    except:
        logger.setLevel(logging.DEBUG)

    formatter = logging.Formatter(log_format)

    # configures stdout
    h = logging.StreamHandler(stream=sys.stdout)
    h.setFormatter(formatter)

    logger.addHandler(h)

    return logger
