"""
    __MAIN__
    ========

    Package main file

    .. Copyright:
        Copyright 2018 Wirepas Ltd. All Rights Reserved.
        See file LICENSE.txt for full license details.
"""

from wirepas_gateway.transport_service import main as main_transport


def main():
    main_transport()


if __name__ == "__main__":
    main()
