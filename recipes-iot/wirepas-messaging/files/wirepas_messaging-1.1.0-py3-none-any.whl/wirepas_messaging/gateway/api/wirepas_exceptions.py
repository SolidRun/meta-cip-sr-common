# Wirepas Oy


class GatewayAPIParsingException(Exception):
    """
    Wirepas Gateway API generic Exception
    """
    pass
